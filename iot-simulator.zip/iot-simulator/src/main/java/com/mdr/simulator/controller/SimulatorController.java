
package com.mdr.simulator.controller;

import com.mdr.simulator.model.DeviceRegistryModel;
import com.mdr.simulator.service.SimulatorService;
import com.mdr.simulator.utils.response.Response;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

@RestController
@CrossOrigin(origins= {"http://0.0.0.0:4200","http://gcbadmin.gladiusiot.com:4200", "http://localhost:4200", "http://ec2-18-218-15-70.us-east-2.compute.amazonaws.com:4200", "http://iotplatform.southindia.cloudapp.azure.com:4200"})
public class SimulatorController{

    private static final Logger LOGGER = LoggerFactory.getLogger(SimulatorController.class);

    @Autowired
    private Environment environment;

    @Autowired
    SimulatorService simulatorService;
        
    @PostMapping(value = "/simulate/start")
    public Response startJob(@Valid @RequestBody String jsonString) throws JobExecutionException, MqttException {
        LOGGER.info("API call is made to the path - /simulate/start");
        return simulatorService.startSimulation(jsonString);
    }
    
    @PostMapping(value = "/simulate/loop")
    public Response loopJob(@RequestBody String jsonString)  throws MqttException, JobExecutionException  {
    	return simulatorService.loopSimulation(jsonString);
    }
    
    @PostMapping (value = "/simulate/alarm")
    public Response alarmJob(@Valid @RequestBody String jsonString) throws MqttException, IOException, NoSuchJobException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException{
        LOGGER.info("API call is made to the path - /simulate/alarm");
        return simulatorService.alarmSimulation(jsonString);
    }
    
    @PostMapping (value = "/simulate/upload/{filetype}/{frequency}")
    public Response uploadFileJob(MultipartFile file, @PathVariable("filetype") String fileType, @PathVariable("frequency") String frequency) throws JobExecutionException, MqttException, IOException {
        LOGGER.info("API call is made to the path - /simulate/upload");
        
        if(file==null){
        	LOGGER.info("File is Missing.");
        	throw new MultipartException("No file uploaded");
        }
        
        String uploadDirectory = environment.getProperty("global.uploadDirectory");
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        
        final Path fileStorageLocation = Paths.get(uploadDirectory).toAbsolutePath().normalize();

        Files.createDirectories(fileStorageLocation);
        Path targetLocation = fileStorageLocation.resolve(fileName);
        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
        
        return simulatorService.fileDataSimulation(fileName, fileType, frequency);
    }
    
    @GetMapping(value = "/simulate/stop/{jobId}")
    public Response stopJob(@PathVariable("jobId") String jobId) throws NoSuchJobException, NoSuchJobExecutionException, JobExecutionNotRunningException {
        LOGGER.info("API call is made to the path - /simulate/stop");
    	return simulatorService.stopSimulation(jobId);
    }
    
    @GetMapping(value = "/simulate/jobstatus")
    public Response JobStatus() throws JobExecutionException {
        LOGGER.info("API call is made to the path - /simulate/jobstatus");
    	return simulatorService.getJobStatus();
    }
    
   /* @PostMapping(value = "/simulate/getDeviceList")
    public List<DeviceRegistryModel> getDeviceRegistry(@RequestBody String accountId []) {
        LOGGER.info("API call is made to the path - /simulate/jobstatus");
    	return simulatorService.getRegisteredDevices(accountId);
    }*/
    
    @PostMapping(value = "/simulate/getDeviceList")
    public List<DeviceRegistryModel> getDeviceRegistry() {
        LOGGER.info("API call is made to the path - /simulate/jobstatus");
    	return simulatorService.getRegisteredDevices();
    }
}