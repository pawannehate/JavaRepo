package com.mdr.simulator.config;

import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import org.springframework.integration.mqtt.support.MqttHeaders;

@EnableIntegration
@IntegrationComponentScan
@Component
public class MQTTConfig {
	
	//private static final Logger LOGGER = LoggerFactory.getLogger(MQTTConfig.class);
	private static String mqttConnectionURL; 
	private static String mqttUserName;
	private static String mqttPassword;
	private static String mqttQos;
	
	public MQTTConfig(Environment environment) {
		if(environment.getProperty("global.mqttConnectionURL") != null)
			MQTTConfig.mqttConnectionURL = environment.getProperty("global.mqttConnectionURL");

		if(environment.getProperty("global.mqttUserName") != null)
			MQTTConfig.mqttUserName = environment.getProperty("global.mqttUserName");
		
		if(environment.getProperty("global.mqttPassword") != null)
			MQTTConfig.mqttPassword = environment.getProperty("global.mqttPassword");
		
		if(environment.getProperty("global.mqttQos") != null)
			MQTTConfig.mqttQos = environment.getProperty("global.mqttQos");
	}
	
	@Bean
    public MqttPahoClientFactory mqttClientFactory() throws MqttException {
        //LOGGER.info(MQTTConfig.mqttConnectionURL+" "+MQTTConfig.mqttUserName+" "+MQTTConfig.mqttPassword+" "+MQTTConfig.mqttQos);
		
		DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setAutomaticReconnect(true);
        options.setCleanSession(true);
        options.setServerURIs(new String[] {MQTTConfig.mqttConnectionURL}); 
        options.setUserName(MQTTConfig.mqttUserName);
        options.setPassword(MQTTConfig.mqttPassword.toCharArray());
        options.setMaxInflight(1000);
        factory.setConnectionOptions(options);
        return factory;
    }

    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler mqttOutbound() throws MqttException {
    	int i=0;
    	String clientId = "MDR"+(++i);
        MqttPahoMessageHandler messageHandler = new MqttPahoMessageHandler(clientId, mqttClientFactory());
        messageHandler.setAsync(true);
        messageHandler.setDefaultQos(Integer.parseInt(MQTTConfig.mqttQos));
        messageHandler.setDefaultTopic("topic/stream");
        return messageHandler;
    }

    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new PublishSubscribeChannel();
    }

    @MessagingGateway(defaultRequestChannel = "mqttOutboundChannel")
    public interface MQTTGateway {
    	
    	void publishData(@Header(MqttHeaders.TOPIC) String topicName, String data);
    }
    
}