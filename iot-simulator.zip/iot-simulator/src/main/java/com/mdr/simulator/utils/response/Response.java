package com.mdr.simulator.utils.response;

public class Response {
    private boolean success;
    private String message;
    private String jobId;
    private String jobDetails;

	public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	
	public String getJobDetails() {
		return jobDetails;
	}
	
	public void setJobDetails(String jobDetails) {
		this.jobDetails = jobDetails;
	}
	
	public Response(){
		super();
	}

	public Response(boolean success, String message) {
		super();
		this.success = success;
		this.message = message;
	}

	public Response(boolean success, String message, String jobId) {
		super();
		this.success = success;
		this.message = message;
		this.jobId = jobId;
	}

	public Response(boolean success, String message, String jobId, String jobDetails) {
		super();
		this.success = success;
		this.message = message;
		this.jobId = jobId;
		this.jobDetails = jobDetails;
	}
	
		
}
