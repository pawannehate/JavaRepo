package com.mdr.simulator.utils;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mdr.simulator.config.MQTTConfig;
import com.mdr.simulator.model.FileSimulationModel;


public class FileSimulationProcessor implements ItemProcessor<FileSimulationModel,FileSimulationModel> {
	
	ApplicationContext ctx = new AnnotationConfigApplicationContext(MQTTConfig.class);
	MQTTConfig.MQTTGateway mqttGateway = ctx.getBean(MQTTConfig.MQTTGateway.class);
	
    private static final Logger LOGGER = LoggerFactory.getLogger(FileSimulationProcessor.class);
    private JobParameters jobParameters;
    private String fileType;
    private Long frequencyValue;
    private String frequencyUnit;
    private static final String TOPIC_NAME_PREFIX = "gladiusIotTopic/";
    
    SimpleDateFormat localDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    
    @BeforeStep
    public void beforeStep(final StepExecution stepExecution) throws MqttException {
    	jobParameters = stepExecution.getJobParameters();
        this.fileType = jobParameters.getString("fileType");
        if(jobParameters.getLong("frequencyValue") != 0) {
        	this.frequencyValue = jobParameters.getLong("frequencyValue");
            this.frequencyUnit = jobParameters.getString("frequencyUnit");
        }
        else {
        	this.frequencyValue = 0L;
            this.frequencyUnit = "";
        }
    }
    
	@AfterStep
    public void afterStep() throws InterruptedException {
    	if(this.frequencyUnit.equalsIgnoreCase("sec")) {
    	  	Long timeInMilliSeconds = (long) (frequencyValue * 1000);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else if(this.frequencyUnit.equalsIgnoreCase("min")) {
    		Long timeInMilliSeconds = (long) (frequencyValue * 1000 * 60);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else if(this.frequencyUnit.equalsIgnoreCase("hrs")) {
    		Long timeInMilliSeconds = (long) (frequencyValue * 1000 * 60 * 60);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else if(this.frequencyUnit.equalsIgnoreCase("days")) {
    		Long timeInMilliSeconds = (long) (frequencyValue * 1000 * 60 * 60 * 24);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else{
    		Thread.sleep(0);
    	}
    }
    
    @Override
    public FileSimulationModel process(FileSimulationModel fileSimulationModel) throws Exception {

    	if(fileType.equalsIgnoreCase("alarm")) {
    		JSONObject alarmPayload = new JSONObject();
    		JSONObject source = new JSONObject(); 
    		source.put("site", fileSimulationModel.getSite());
    		source.put("sensor", fileSimulationModel.getTag());
    		source.put("camera", "");
    		source.put("panel", "");
    		alarmPayload.put("n","alarm");
    		alarmPayload.put("gatewayId", fileSimulationModel.getGatewayId());
    		
    		alarmPayload.put("source", source);
    		alarmPayload.put("alarm", fileSimulationModel.getAlarmType());
    		alarmPayload.put("id", fileSimulationModel.getAlarmId());
    		alarmPayload.put("val", fileSimulationModel.getTagValue());
    		alarmPayload.put("reset", "no");
    		alarmPayload.put("resetalarm", "");
    		alarmPayload.put("image", "");
    		alarmPayload.put("video", "");
    		//alarmPayload.put("t",new Timestamp(System.currentTimeMillis()));
    		alarmPayload.put("t",localDateFormat.format(new Date()));
    		

    		mqttGateway.publishData(TOPIC_NAME_PREFIX + fileSimulationModel.getGatewayId(), alarmPayload.toString());
            LOGGER.info("Payload :"+ alarmPayload);
    	}
    	else {
    		JSONObject telemetryPayload = new JSONObject();
        	JSONObject devicePayload = new JSONObject();
        	if(fileSimulationModel.getTagValue() == null){
        		DecimalFormat df = new DecimalFormat(".##");
        		double tagValue = fileSimulationModel.getLowerLimit() + Math.random() * (fileSimulationModel.getHigherLimit() - fileSimulationModel.getLowerLimit());
        		devicePayload.put(fileSimulationModel.getTag(), Double.parseDouble(df.format(tagValue)));
        	}
        	else{
        		devicePayload.put(fileSimulationModel.getTag(), fileSimulationModel.getTagValue());
        	}
        	
        	JSONArray deviceData = new JSONArray();
        	deviceData.put(devicePayload);
        	telemetryPayload.put("n", "data");
        	telemetryPayload.put("deviceData", deviceData);
        	//telemetryPayload.put("t", new Timestamp(System.currentTimeMillis()));
        	telemetryPayload.put("t",localDateFormat.format(new Date()));
        	telemetryPayload.put("gatewayId", fileSimulationModel.getGatewayId());
        	telemetryPayload.put("mid", 101);
        	mqttGateway.publishData(TOPIC_NAME_PREFIX + fileSimulationModel.getGatewayId(), telemetryPayload.toString());	
            LOGGER.info("Payload :"+ telemetryPayload);
    	}
        return fileSimulationModel;
    }
}