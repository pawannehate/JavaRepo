package com.mdr.simulator.model;

import java.util.HashMap;
import java.util.Map;

public class ManualSimulationChildModel {

	private String parent;
	private String child;
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	
	public ManualSimulationChildModel(){

	}
	
	public ManualSimulationChildModel(String parent, String child){
		super();
		this.parent=parent;
		this.child=child;
	}
	
	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public String getChild() {
		return child;
	}

	public void setChild(String child) {
		this.child = child;
	}

	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
}
