package com.mdr.simulator.model;

public class FileSimulationModel {

    private String gatewayId;
    private String tag;
    private Double tagValue;
    private Double lowerLimit;
    private Double higherLimit;
    private String site;
    private String alarmType;
    private String alarmId;
    
    public FileSimulationModel() {
    	
    }

	public FileSimulationModel(String gatewayId, String tag, Double tagValue) {
		super();
		this.gatewayId = gatewayId;
		this.tag = tag;
		this.tagValue = tagValue;
	}
	
	public FileSimulationModel(String gatewayId, String tag, Double lowerLimit, Double higherLimit) {
		super();
		this.gatewayId = gatewayId;
		this.tag = tag;
		this.lowerLimit = lowerLimit;
		this.higherLimit = higherLimit;
	}
	
	public FileSimulationModel(String gatewayId, String tag, Double tagValue, String site, String alarmType, String alarmId) {
		super();
		this.gatewayId = gatewayId;
		this.tag = tag;
		this.tagValue = tagValue;
		this.site = site;
		this.alarmType = alarmType;
		this.alarmId = alarmId;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public Double getTagValue() {
		return tagValue;
	}

	public void setTagValue(Double tagValue) {
		this.tagValue = tagValue;
	}
	
	public Double getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(Double lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public Double getHigherLimit() {
		return higherLimit;
	}

	public void setHigherLimit(Double higherLimit) {
		this.higherLimit = higherLimit;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getAlarmType() {
		return alarmType;
	}

	public void setAlarmType(String alarmType) {
		this.alarmType = alarmType;
	}

	public String getAlarmId() {
		return alarmId;
	}

	public void setAlarmId(String alarmId) {
		this.alarmId = alarmId;
	}

	@Override
	public String toString() {
		return "SimulatorModel [gatewayId=" + gatewayId + ", tag=" + tag + ", tagValue=" + tagValue + ", lowerLimit="
				+ lowerLimit + ", higherLimit=" + higherLimit + ", site=" + site + ", alarmType=" + alarmType
				+ ", alarmId=" + alarmId + "]";
	}
	
}
