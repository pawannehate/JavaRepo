package com.mdr.simulator.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.mdr.simulator.security.JwtUser;
import com.mdr.simulator.utils.response.Response;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtTokenService {
	
	@Autowired
	private Environment environment;

	private SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS512;
	
	public Response generateToken(JwtUser jwtUser) {
		
		int tokenexpiration = Integer.parseInt(environment.getProperty("global.jwt.expiration"));
		String secret = environment.getProperty("global.jwt.secret");
		
		if(jwtUser.getUserId().equals(environment.getProperty("global.jwt.userId"))) {
			if(jwtUser.getUserPassword().equals(environment.getProperty("global.jwt.userPassword"))) {

				Claims claims = Jwts.claims().setSubject(jwtUser.getUserId());
		        claims.put("userPassword", jwtUser.getUserPassword());
		        claims.put("userRole", jwtUser.getUserRole());

		        Date expDate = new Date();
		        Calendar calendar = Calendar.getInstance();
		        calendar.setTime(expDate);
		        calendar.add(Calendar.SECOND, tokenexpiration);
		        expDate = calendar.getTime();
		        String token = Jwts.builder().setClaims(claims).setIssuedAt(new Date()).setExpiration(expDate).signWith(signatureAlgorithm, secret).compact();
		        Response response = new Response(true, token);
		        
				return response;
			}
		}
		Response response = new Response(false, "Invalid credentials.");
		return response;
	}
	
}
