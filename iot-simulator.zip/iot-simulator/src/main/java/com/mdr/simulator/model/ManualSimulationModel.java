package com.mdr.simulator.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class ManualSimulationModel {

	private String assetId;
	private List<ManualSimulationChildModel> pannelId = null;
	private List<String> gatewayId = null;
	private List<ManualSimulationChildModel> tag = null;
	private double tagValue;
	private int lowerLimit;
	private int upperLimit;
	private Long frequencyValue;
	private String frequencyUnit;
	
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public ManualSimulationModel(){
	}

	public ManualSimulationModel(String assetId, List<ManualSimulationChildModel> pannelId, List<String> gatewayId, List<ManualSimulationChildModel> tag, double tagValue) {
		super();
		this.gatewayId = gatewayId;
		this.assetId = assetId;
		this.pannelId = pannelId;
		this.tag = tag;
		this.tagValue = tagValue;
	}
	
	public ManualSimulationModel(String assetId, List<ManualSimulationChildModel> pannelId, List<String> gatewayId, List<ManualSimulationChildModel> tag,
									int lowerLimit, int upperLimit, Long frequencyValue, String frequencyUnit) {
		super();
		this.gatewayId = gatewayId;
		this.assetId = assetId;
		this.pannelId = pannelId;
		this.tag = tag;
		this.upperLimit = upperLimit;
		this.lowerLimit = lowerLimit;
		this.frequencyValue = frequencyValue;
		this.frequencyUnit = frequencyUnit;
	}
	
	public ManualSimulationModel(String assetId, List<ManualSimulationChildModel> tag, double tagValue) {
		super();
		this.assetId = assetId;
		this.tag = tag;
		this.tagValue = tagValue;
	}
	
	public ManualSimulationModel(String assetId, List<ManualSimulationChildModel> tag, double tagValue,
			int lowerLimit, int upperLimit, Long frequencyValue, String frequencyUnit) {
		super();
		this.assetId = assetId;
		this.tag = tag;
		this.upperLimit = upperLimit;
		this.lowerLimit = lowerLimit;
		this.frequencyValue = frequencyValue;
		this.frequencyUnit = frequencyUnit;
	}

	public String getAssetId() {
		return assetId;
	}
	
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	
	public List<ManualSimulationChildModel> getPannelId() {
		return pannelId;
	}
	
	public void setPannelId(List<ManualSimulationChildModel> pannelId) {
		this.pannelId = pannelId;
	}
	
	public List<String> getGatewayId() {
		return gatewayId;
	}
	
	public void setGatewayId(List<String> gatewayId) {
		this.gatewayId = gatewayId;
	}
	
	public List<ManualSimulationChildModel> getTag() {
		return tag;
	}
	
	public void setTag(List<ManualSimulationChildModel> tag) {
		this.tag = tag;
	}
	
	public double getTagValue() {
		return tagValue;
	}
	
	public void setTagValue(double tagValue) {
		this.tagValue = tagValue;
	}
	
	public Integer getLowerLimit() {
		return lowerLimit;
	}
	
	public void setLowerLimit(int lowerLimit) {
		this.lowerLimit = lowerLimit;
	}
	
	public Integer getUpperLimit() {
		return upperLimit;
	}
	
	public void setUpperLimit(int upperLimit) {
		this.upperLimit = upperLimit;
	}
	
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}
	
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	public Long getFrequencyValue() {
		return frequencyValue;
	}

	public void setFrequencyValue(Long frequencyValue) {
		this.frequencyValue = frequencyValue;
	}

	public String getFrequencyUnit() {
		return frequencyUnit;
	}

	public void setFrequencyUnit(String frequencyUnit) {
		this.frequencyUnit = frequencyUnit;
	}

	@Override
	public String toString() {
		return "ManualSimulationModel [assetId=" + assetId + ", pannelId=" + pannelId + ", gatewayId=" + gatewayId
				+ ", tag=" + tag + ", tagValue=" + tagValue + ", lowerLimit=" + lowerLimit + ", upperLimit="
				+ upperLimit + ", frequencyValue=" + frequencyValue + ", frequencyUnit=" + frequencyUnit
				+ ", additionalProperties=" + additionalProperties + "]";
	}
}