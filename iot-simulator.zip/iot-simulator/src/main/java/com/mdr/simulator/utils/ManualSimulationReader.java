package com.mdr.simulator.utils;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mdr.simulator.model.ManualSimulationModel;

public class ManualSimulationReader implements ItemReader<ManualSimulationModel> {


	private int nextDataIndex;
    private List<ManualSimulationModel> simulatorDataList;
	private final String jsonString;
    private ManualSimulationModel simulatorData;
 
    public ManualSimulationReader(String jsonString) throws JsonParseException, JsonMappingException, IOException {
        	
    	this.jsonString = jsonString;
        ObjectMapper mapper = new ObjectMapper();
        this.simulatorData = mapper.readValue(this.jsonString, ManualSimulationModel.class);
        simulatorDataList = Collections.unmodifiableList(Arrays.asList(simulatorData));
        nextDataIndex = 0;
    }
    
    @Override
    public ManualSimulationModel read() throws Exception {
    	ManualSimulationModel nextSimulatorData = null;
        if (nextDataIndex < simulatorDataList.size()) {
            nextSimulatorData = simulatorDataList.get(nextDataIndex);
            nextDataIndex++;
        }
        return nextSimulatorData;
    }

}