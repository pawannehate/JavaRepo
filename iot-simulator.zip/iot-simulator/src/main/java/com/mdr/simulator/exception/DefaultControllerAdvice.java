package com.mdr.simulator.exception;

import com.mdr.simulator.utils.response.ErrorResponse;

import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.io.FileNotFoundException;
import java.io.IOException;

@EnableWebMvc
@ControllerAdvice
@RestController
public class DefaultControllerAdvice {

    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultControllerAdvice.class);

    @ExceptionHandler(MqttException.class)
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    public ErrorResponse mqttServerException(final MqttException e){
        LOGGER.info("MqttException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0001",
                false,"Error in communicating with the MQTT server",
                e.getMessage());
        return errorResponse;
    }

    @ExceptionHandler(NoSuchJobExecutionException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse batchNoSuchJobExecutionException(final NoSuchJobExecutionException e){
        LOGGER.info("NoSuchJobExecutionException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0002",
                false,"The attempted job does not exist",
                e.getMessage());
        return errorResponse;
    }

    @ExceptionHandler(JobExecutionNotRunningException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse JobExecutionNotRunningException(final JobExecutionNotRunningException e){
        LOGGER.info("JobExecutionNotRunningException is created.");
      
        ErrorResponse errorResponse = new ErrorResponse("x0003",
                false,"The job is not running",
                e.getMessage());
        return errorResponse;
    }

    @ExceptionHandler(JobExecutionException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse batchJobExecutionException(final JobExecutionException e){
        LOGGER.info("JobExecutionException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0004",
                false,"The attempted job is not running.",
                e.getMessage());
        return errorResponse;
    }
    
    @ExceptionHandler(IOException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse ioExecutionException(final IOException e){
        LOGGER.info("IOException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0005",
                false,"Error related to the file",
                e.getMessage());
        return errorResponse;
    }
    
    @ExceptionHandler(FileNotFoundException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse fileNotFoundException (final FileNotFoundException e){
        LOGGER.info("fileNotFoundException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0006",
                false,"Required data file is not found.");
        return errorResponse;
    }
    
    @ExceptionHandler(MultipartException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse MultipartException(final MultipartException e){
        LOGGER.info("MultipartException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0007",
                false,"File type error",
                e.getMessage());
        return errorResponse;
    }
    
    @ExceptionHandler(SignatureException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse signatureException (final SignatureException e){
        LOGGER.info("SignatureException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0008",
                false,"Invalid Token.");
        return errorResponse;
    }
    
    @ExceptionHandler(MalformedJwtException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse malformedJwtException (final MalformedJwtException e){
        LOGGER.info("MalformedJwtException is created.");
        ErrorResponse errorResponse = new ErrorResponse("x0009",
                false,"Invalid Token.");
        return errorResponse;
    }
  
}
