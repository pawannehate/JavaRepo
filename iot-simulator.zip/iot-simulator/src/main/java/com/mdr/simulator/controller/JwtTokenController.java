package com.mdr.simulator.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mdr.simulator.security.JwtUser;
import com.mdr.simulator.service.JwtTokenService;
import com.mdr.simulator.utils.response.Response;

@RestController
@CrossOrigin(origins= {"http://0.0.0.0:4200","http://gcbadmin.gladiusiot.com:4200","http://ec2-18-217-183-204.us-east-2.compute.amazonaws.com:4200","http://localhost:4200","http://iotplatform.southindia.cloudapp.azure.com:4200"})
@RequestMapping("/simulation/token")
public class JwtTokenController {
	
	@Autowired
	private JwtTokenService jwtTokenService;
	
	@PostMapping
	public Response generate(@Valid @RequestBody JwtUser jwtUser) {
		return jwtTokenService.generateToken(jwtUser);
	}

}
