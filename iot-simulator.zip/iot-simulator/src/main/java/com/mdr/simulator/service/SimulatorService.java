package com.mdr.simulator.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttSecurityException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.mdr.simulator.model.DeviceRegistryModel;
import com.mdr.simulator.utils.DeviceRegistry;
import com.mdr.simulator.utils.response.Response;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class SimulatorService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SimulatorService.class);
	
	@Autowired
	private Environment environment;
	
	@Autowired
	@Qualifier("fileSimulationJob")
    Job job;
	
	@Autowired
	JobRegistry jobRegistry;
	
	@Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private JobExplorer jobExplorer;
	
	@Autowired
    private JobOperator jobOperator;
		
	private DeviceRegistry deviceRegistry; 
	
    private Response response;
    
    public SimulatorService(DeviceRegistry deviceRegistry) {
    	this.deviceRegistry = deviceRegistry;
    }
    
    public Response startSimulation(@RequestBody String jsonString) throws MqttException, JobExecutionException {

    	checkMqttConnection();
		Long uId = System.currentTimeMillis();
		JobParameters jobParameters = new JobParametersBuilder().addLong("jobId", uId)
	   			.addString("jsonString", jsonString)
	   			.addString("simulationType", "telemetry")
	   			.toJobParameters();
		
		job = jobRegistry.getJob("manualSimulationJob");
		JobExecution jobExecution = jobLauncher.run(job,jobParameters);
				
	   	Response response = new Response(true, "Simulation successfully started.", String.valueOf(jobExecution.getJobId()));
		return response;
	}
    
    public Response loopSimulation(@RequestBody String jsonString) throws MqttException,JobExecutionException {
    	
    	checkMqttConnection();
    	
		Long uId = System.currentTimeMillis();
		JobParameters jobParameters = new JobParametersBuilder().addLong("jobId", uId)
	   			.addString("jsonString", jsonString)
	   			.addString("simulationType", "telemetryloop")
	   			.toJobParameters();
			
		job = jobRegistry.getJob("manualLoopSimulationJob");
		JobExecution jobExecution = jobLauncher.run(job,jobParameters);
		
	   	Response response = new Response(true, "Simulation successfully started in loop mode.", String.valueOf(jobExecution.getJobId()));
		return response;
	}
    
    public Response alarmSimulation(String jsonString) throws MqttException, IOException, NoSuchJobException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {	
		
    	checkMqttConnection();			
		
		Long uId = System.currentTimeMillis();
		JobParameters jobParameters = new JobParametersBuilder().addLong("jobId", uId)
	   			.addString("jsonString", jsonString)
	   			.addString("simulationType", "alarm")
	   			.toJobParameters();
			
		job = jobRegistry.getJob("manualSimulationJob");
		JobExecution jobExecution = jobLauncher.run(job,jobParameters);
				
	   	Response response = new Response(true, "Alarm generated.", String.valueOf(jobExecution.getJobId()));
		return response;
	}
    
	public Response fileDataSimulation(String fileName, String fileType, String frequency) throws MqttException, JobExecutionException{
		
		checkMqttConnection();

		if(fileType.equalsIgnoreCase("telemetry")) {
			long uId = System.currentTimeMillis();
			JobParameters jobParameters = new JobParametersBuilder().addLong("uId", uId)
					.addString("fileName", fileName)
					.addString("fileType", fileType)
					.toJobParameters();
			job = jobRegistry.getJob("fileSimulationJob");
			JobExecution jobExecution = jobLauncher.run(job,jobParameters);
			response = new Response(true, "Simulation successfully started.", String.valueOf(jobExecution.getJobId()));
		}
		else if(fileType.equalsIgnoreCase("telemetryloop")){
			Pattern p = Pattern.compile("\\d+");
			Matcher m = p.matcher(frequency);
			Long frequencyValue = 1L;
			String frequencyUnit = "sec";
			
			while(m.find()) {
				frequencyValue = Long.parseLong(m.group());
				break;
	        }
			frequencyUnit = frequency.replaceAll("[0-9]", "");
			
			long uId = System.currentTimeMillis();
			JobParameters jobParameters = new JobParametersBuilder().addLong("uId", uId)
					.addString("fileName", fileName)
					.addString("fileType", fileType)
					.addLong("frequencyValue", frequencyValue)
					.addString("frequencyUnit", frequencyUnit)
					.toJobParameters();
			job = jobRegistry.getJob("fileLoopSimulationJob");
			JobExecution jobExecution = jobLauncher.run(job,jobParameters);
			
			response = new Response(true, "Simulation successfully started in loop mode.", String.valueOf(jobExecution.getJobId()));
			
		}
		else if(fileType.equalsIgnoreCase("alarm")) {
			long uId = System.currentTimeMillis();
			JobParameters jobParameters = new JobParametersBuilder().addLong("uId", uId)
					.addString("fileName", fileName)
					.addString("fileType", fileType)
					.toJobParameters();
			job = jobRegistry.getJob("fileSimulationJob");
			JobExecution jobExecution = jobLauncher.run(job,jobParameters);
			response = new Response(true, "Alarm generated.", String.valueOf(jobExecution.getJobId()));
		}
		else {
			response = new Response(false, "This type of simulation is not Supported.");
		}
		
		return response;
	}
	
	public Response stopSimulation(String jobId) throws NoSuchJobException, NoSuchJobExecutionException, JobExecutionNotRunningException  {
		
		List<JobInstance> jobInstances = new ArrayList <JobInstance>();
		
		if(jobExplorer.findRunningJobExecutions("manualSimulationJob").size() != 0)
			jobInstances.addAll(jobExplorer.getJobInstances("manualSimulationJob",0,jobExplorer.getJobInstanceCount("manualSimulationJob"))); 
		
		if(jobExplorer.findRunningJobExecutions("manualLoopSimulationJob").size() != 0)
			jobInstances.addAll(jobExplorer.getJobInstances("manualLoopSimulationJob",0,jobExplorer.getJobInstanceCount("manualLoopSimulationJob"))); 
		
		if(jobExplorer.findRunningJobExecutions("fileSimulationJob").size() != 0)
			jobInstances.addAll(jobExplorer.getJobInstances("fileLoopSimulationJob",0,jobExplorer.getJobInstanceCount("fileSimulationJob")));

		if(jobExplorer.findRunningJobExecutions("fileLoopSimulationJob").size() != 0)
			jobInstances.addAll(jobExplorer.getJobInstances("fileLoopSimulationJob",0,jobExplorer.getJobInstanceCount("fileLoopSimulationJob")));
		
    	for (JobInstance jobInstance : jobInstances) {
    	    List<JobExecution> jobExecutions = jobExplorer.getJobExecutions(jobInstance);
    	    for (JobExecution jobExecution : jobExecutions) {
    	        if (jobExecution.isRunning()) {
    	        	jobOperator.stop(Long.parseLong(jobId));
    	        	LOGGER.info("Job stopped. ID="+jobId);
    	        	return response = new Response(true, "Simulation successfully stopped.", jobId);
    	        }
    	     }
    	}
        return response = new Response(true, "Simulation not running.");
	}
	
	public Response getJobStatus() throws NoSuchJobException, NoSuchJobExecutionException {
		JSONArray jobStatus  = new JSONArray();
		
		Set<Long> runningJobInstances = jobOperator.getRunningExecutions("manualSimulationJob");
		runningJobInstances.addAll(jobOperator.getRunningExecutions("manualLoopSimulationJob"));
		runningJobInstances.addAll(jobOperator.getRunningExecutions("fileSimulationJob"));
		runningJobInstances.addAll(jobOperator.getRunningExecutions("fileLoopSimulationJob"));
		
		int runningJobCount = runningJobInstances.size();
		
		for (Long instance : runningJobInstances) {
			JSONObject jobObj = new JSONObject();
			String runningInstanceInfo= jobOperator.getParameters(instance);
			jobObj.put("jobId", String.valueOf(instance));
			jobObj.put("jobDetails", runningInstanceInfo);
			jobObj.put("jobStatus", "Running");
			jobStatus.put(jobObj);
		}
		
		return response = new Response(true, "Running simulation count: "+runningJobCount, null, jobStatus.toString());
	}
	
	public void checkMqttConnection() throws MqttSecurityException, MqttException {
	
		MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(environment.getProperty("global.mqttUserName"));
        options.setPassword(environment.getProperty("global.mqttPassword").toCharArray());
        MqttClient client = new MqttClient(environment.getProperty("global.mqttConnectionURL"), MqttClient.generateClientId());
		client.connect(options);
		
		if(!client.isConnected())
			throw new RuntimeException();
		else
			client.disconnect();
	}

	public List<DeviceRegistryModel> getRegisteredDevices() {
		return deviceRegistry.findAll();
	}
	
	/*public List<DeviceRegistryModel> getRegisteredDevices(String accountId[]) {
		return deviceRegistry.getDeviceInfo(accountId);
	}*/
}

