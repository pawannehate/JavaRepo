package com.mdr.simulator.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "DeviceRegister")
public class DeviceRegistryModel {
	@Id
	public String _id;
	   
	public String deviceType;
	public String classification;
	public String deviceStatus;
	public String deviceDisplayName;
	public String gatewayParentId;
	public String deviceNativeId;
	public String gatewayId;
	  
	public DeviceRegistryModel() {
		
	}

	public DeviceRegistryModel(String _id, String deviceType, String classification, String deviceStatus,
			String deviceDisplayName, String gatewayParentId, String deviceNativeId, String gatewayId) {
		super();
		this._id = _id;
		this.deviceType = deviceType;
		this.classification = classification;
		this.deviceStatus = deviceStatus;
		this.deviceDisplayName = deviceDisplayName;
		this.gatewayParentId = gatewayParentId;
		this.deviceNativeId = deviceNativeId;
		this.gatewayId = gatewayId;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getDeviceStatus() {
		return deviceStatus;
	}

	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}

	public String getDeviceDisplayName() {
		return deviceDisplayName;
	}

	public void setDeviceDisplayName(String deviceDisplayName) {
		this.deviceDisplayName = deviceDisplayName;
	}

	public String getGatewayParentId() {
		return gatewayParentId;
	}

	public void setGatewayParentId(String gatewayParentId) {
		this.gatewayParentId = gatewayParentId;
	}

	public String getDeviceNativeId() {
		return deviceNativeId;
	}

	public void setDeviceNativeId(String deviceNativeId) {
		this.deviceNativeId = deviceNativeId;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}


	
	  
}
