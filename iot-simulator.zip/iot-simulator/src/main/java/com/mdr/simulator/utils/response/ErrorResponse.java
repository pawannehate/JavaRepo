package com.mdr.simulator.utils.response;

public class ErrorResponse{

    private String errorCode;
    private Boolean success;
    private String message;
    private String checkedExceptionMessage;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCheckedExceptionMessage() {
        return checkedExceptionMessage;
    }

    public void setCheckedExceptionMessage(String checkedExceptionMessage) {
        this.checkedExceptionMessage = checkedExceptionMessage;
    }

    public ErrorResponse(){

    }

    public ErrorResponse(String errorCode, Boolean success, String message) {
        //super(success, message,errorCode);
        this.errorCode = errorCode;
        this.success = success;
        this.message = message;
        this.checkedExceptionMessage = "NIL";
    }

    public ErrorResponse(String errorCode, Boolean success, String message, String checkedExceptionMessage) {
        //super(success, checkedExceptionMessage, errorCode);
        this.errorCode = errorCode;
        this.success = success;
        this.message = message;
        this.checkedExceptionMessage = checkedExceptionMessage;
    }

}
