package com.mdr.simulator.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.ListableJobLocator;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobOperator;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mdr.simulator.model.FileSimulationModel;
import com.mdr.simulator.model.ManualSimulationModel;
import com.mdr.simulator.utils.ManualSimulationReader;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

@Configuration
@EnableBatchProcessing
public class BatchConfig {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchConfig.class);
	
    @Autowired
    private JobBuilderFactory jobs;

    @Autowired
    private StepBuilderFactory steps;

    @Autowired
    private JobRepository jobRepository;
    
    @Autowired
    private Environment environment;
    
    private static final String OVERRIDDEN_BY_EXPRESSION = null;
	
    @Bean(name = "manualLoopSimulationJob")
    public Job manualSimulationLoopJob() throws JsonParseException, JsonMappingException, IOException{
        return jobs.get("manualLoopSimulationJob").flow(step1()).next(step1()).end().build();
    }

	@Bean(name="manualSimulationJob")
    public Job manualSimulationJob() throws JsonParseException, JsonMappingException, IOException{
        return jobs.get("manualSimulationJob").flow(step1()).end().build();
    }
	
	@Bean(name = "fileSimulationJob")
    public Job fileSimulationJob(){
        return jobs.get("fileSimulationJob").flow(step()).build().build();
    }
	
    @Bean(name = "fileLoopSimulationJob")
    public Job fileLoopSimulationJob(){
    	return jobs.get("fileLoopSimulationJob").flow(step()).next(step()).end().build();
    }
    
    @Bean
    public Step step1() throws JsonParseException, JsonMappingException, IOException{
		return steps.get("step1")
                .<ManualSimulationModel,ManualSimulationModel>chunk(1)
                .reader(manualItemReader(OVERRIDDEN_BY_EXPRESSION))
                .processor(new com.mdr.simulator.utils.ManualSimulationProcessor())
                .writer(write1())
                .build();
    }
    
    @Bean
    public Step step(){
        return steps.get("step")
                .<FileSimulationModel,FileSimulationModel>chunk(1)
                .reader(reader(OVERRIDDEN_BY_EXPRESSION,OVERRIDDEN_BY_EXPRESSION))
                .processor(new com.mdr.simulator.utils.FileSimulationProcessor())
                .writer(write())
                .build();
    }

	@Bean
	@StepScope
	ItemReader<ManualSimulationModel> manualItemReader(@Value("#{jobParameters[jsonString]}") String jsonString) throws JsonParseException, JsonMappingException, IOException {
	        	 return new ManualSimulationReader(jsonString);
	}
    
    @Bean
    @StepScope
    public FlatFileItemReader<FileSimulationModel> reader(@Value("#{jobParameters[fileName]}") String fileName, @Value("#{jobParameters[fileType]}") String fileType){
    	
		String resourceDirectory = Paths.get(environment.getProperty("global.telemetoryDataFilePath")).toAbsolutePath().normalize().toString();
		
		if(!new File(resourceDirectory, fileName).exists()) {
			LOGGER.info("Resource file not found!");
		}
		
		Resource resource = new FileSystemResource(resourceDirectory+"/"+fileName);
		FlatFileItemReader<FileSimulationModel> reader = new FlatFileItemReader<>();
	        
		reader.setResource(resource);
		reader.setLinesToSkip(1);
		reader.setLineMapper(new DefaultLineMapper<FileSimulationModel>(){
            {
                setLineTokenizer(new DelimitedLineTokenizer(){
                    {
                    	if(fileType.equalsIgnoreCase("telemetry")) {
	                    	setNames((new String[]{
	                            "gatewayId","tag","tagValue"
	                        }));
                    	}
                    	else if ((fileType.equalsIgnoreCase("telemetryloop"))){
                    		setNames((new String[]{
                    				"gatewayId","tag","lowerLimit","higherLimit"
                    		}));
                    	}
                    	else {
                    		setNames((new String[]{
                    				"gatewayId","site","tag","alarmType","alarmId","tagValue"
                    		}));
                    		setIncludedFields(0, 1, 2, 5, 6, 7);
                    	}
                    }
                });
                setFieldSetMapper(new BeanWrapperFieldSetMapper<FileSimulationModel>(){
                    {
                        setTargetType(FileSimulationModel.class);
                    }
                });
            }
        });
        reader.close();
        return reader;
    }
    
    @Bean
    public ItemWriter<ManualSimulationModel> write1(){
        return new ItemWriter<ManualSimulationModel>() {
            @Override
        	public void write(List<? extends ManualSimulationModel> items) throws Exception {
            }
        };
    }
    
    @Bean
    public ItemWriter<FileSimulationModel> write(){
        return new ItemWriter<FileSimulationModel>() {
            @Override
            public void write(List<? extends FileSimulationModel> items) throws Exception {
            }
        };
    }
    
    @Bean
    public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
	    JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
	    jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
	    return jobRegistryBeanPostProcessor;
	}

    @Bean
    public JobLauncher jobLauncher() throws Exception{
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
        jobLauncher.afterPropertiesSet();
        return jobLauncher;
    }
    
    @Bean
    @ConditionalOnMissingBean(JobOperator.class)
	public JobOperator jobOperator(JobExplorer jobExplorer, JobLauncher jobLauncher, ListableJobLocator jobRegistry, JobRepository jobRepository) throws Exception {
		SimpleJobOperator jobOperator = new SimpleJobOperator();
		jobOperator.setJobExplorer(jobExplorer);
		jobOperator.setJobLauncher(jobLauncher);
		jobOperator.setJobRegistry(jobRegistry);
		jobOperator.setJobRepository(jobRepository);
		return jobOperator;
	}
}