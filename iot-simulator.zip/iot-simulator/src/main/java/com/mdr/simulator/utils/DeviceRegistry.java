package com.mdr.simulator.utils;

import java.lang.reflect.Array;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.mdr.simulator.model.DeviceRegistryModel;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

@Repository
public interface DeviceRegistry extends MongoRepository<DeviceRegistryModel, String>{
	
	
	//@Query("{$and:[{'deviceStatus':'Active'},{$or:[{ 'account' : { 'accountName': 'Mindtree Ltd', '_id' : 'MTAC10001' } }, { 'account' : { 'accountName' : 'Mindtree Ltd', '_id' : 'MTAC10002' } }]}]}")
	
	@Query("{$and:[{'deviceStatus':'Active'},{'account._id':{$in :?0}}]}")
	List<DeviceRegistryModel> getDeviceInfo(String arr[]);
	
	List<DeviceRegistryModel> findAll();
}
