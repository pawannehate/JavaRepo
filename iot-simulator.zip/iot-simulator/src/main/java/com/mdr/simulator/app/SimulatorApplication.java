package com.mdr.simulator.app;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@ComponentScan({"com.mdr.simulator.app", "com.mdr.simulator.config", "com.mdr.simulator.controller",
	"com.mdr.simulator.model", "com.mdr.simulator.security", "com.mdr.simulator.service",
	"com.mdr.simulator.utils", "com.mdr.simulator.exception"})
@IntegrationComponentScan("com.mdr.simulator.config")
@SpringBootApplication
@EnableBatchProcessing
@EnableScheduling
@EnableAutoConfiguration
@EnableMongoRepositories({"com.mdr.simulator.utils"}) 
public class SimulatorApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(SimulatorApplication.class, args);
	}
	
}
