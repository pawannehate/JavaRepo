package com.mdr.simulator.utils;


import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mdr.simulator.config.MQTTConfig;
//import com.mdr.simulator.config.MQTTConfig;
import com.mdr.simulator.model.ManualSimulationChildModel;
import com.mdr.simulator.model.ManualSimulationModel;


public class ManualSimulationProcessor implements ItemProcessor<ManualSimulationModel,ManualSimulationModel> {

	ApplicationContext ctx = new AnnotationConfigApplicationContext(MQTTConfig.class);
    MQTTConfig.MQTTGateway mqttGateway = ctx.getBean(MQTTConfig.MQTTGateway.class);
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ManualSimulationProcessor.class);
    
    private double tagValue = 0;
    private Long frequencyValue = 0L;
    private String frequencyUnit;
    private String simulationType;
    private JobParameters jobParameters;
    private static final String TOPIC_NAME_PREFIX = "gladiusIotTopic/";
    SimpleDateFormat localDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    
    
    @BeforeStep
    public void beforeStep(final StepExecution stepExecution) {
        jobParameters = stepExecution.getJobParameters();
        this.simulationType= jobParameters.getString("simulationType");
    }
    
    @Override
    public ManualSimulationModel process(ManualSimulationModel manualSimulationModel) throws Exception {
 
    	if(this.simulationType.equals("telemetry") || this.simulationType.equals("telemetryloop") || this.simulationType.equals("alarm")){
    		tagValue = manualSimulationModel.getTagValue();
    		
        	JSONObject payload;
        	JSONObject devicePayload;
        	JSONArray deviceData;
        	
        	if(this.simulationType.equals("telemetryloop")) {
        		this.frequencyValue = manualSimulationModel.getFrequencyValue();
        		this.frequencyUnit = manualSimulationModel.getFrequencyUnit();
        	}
        	else {
        		this.frequencyValue = 0L;
        		this.frequencyUnit = "";
        	}
        	
        	// For simulation started for selected tag only
        	if(manualSimulationModel.getGatewayId() == null) {
        		payload = new JSONObject();
        		
        		for(ManualSimulationChildModel tag : manualSimulationModel.getTag()) {
        			deviceData = new JSONArray();
        			devicePayload= new JSONObject();
        			
        			//If value is provided else range is provided
        			if(manualSimulationModel.getTagValue() != 0) {
            			this.tagValue = manualSimulationModel.getTagValue();
            		}
            		else {
            			DecimalFormat df = new DecimalFormat(".##");
            			double value = manualSimulationModel.getLowerLimit() + Math.random() * (manualSimulationModel.getUpperLimit() - manualSimulationModel.getLowerLimit());
            			this.tagValue = Double.parseDouble(df.format(value));
            		}
        			
        			devicePayload.put(tag.getChild(), this.tagValue);
        			
        			deviceData.put(devicePayload);
        			
        			if(this.simulationType.equals("alarm"))
        				payload.put("n", "alarm");
        			else
        				payload.put("n", "data");
    	        	
    	        	payload.put("deviceData", deviceData);
    	        	//payload.put("t", new Timestamp(System.currentTimeMillis()));
    	        	payload.put("t",localDateFormat.format(new Date()));
    	        	payload.put("gatewayId", tag.getParent());
    	        	payload.put("mid", 101);
    	        	
    	        	mqttGateway.publishData(TOPIC_NAME_PREFIX + tag.getParent(), payload.toString()); 
    	        	LOGGER.info("Payload :"+ payload);
        		}
        	}
        	// For simulation started for selected all gateway and selected gateway
        	else {
        		for(String gateway : manualSimulationModel.getGatewayId()) {
            		payload = new JSONObject();
         			deviceData = new JSONArray();
            		for(ManualSimulationChildModel tag : manualSimulationModel.getTag()) {
            			devicePayload= new JSONObject();
           
            			if(gateway.equals(tag.getParent())){
            				
            				//If value is provided else range is provided
            				if(manualSimulationModel.getTagValue() != 0) {
                    			this.tagValue = manualSimulationModel.getTagValue();
                    		}
                    		else {
                    			DecimalFormat df = new DecimalFormat(".##");
                    			double value = manualSimulationModel.getLowerLimit() + Math.random() * (manualSimulationModel.getUpperLimit() - manualSimulationModel.getLowerLimit());
                    			this.tagValue = Double.parseDouble(df.format(value));
                    		}
            				
            				devicePayload.put(tag.getChild(), this.tagValue);
            	    		deviceData.put(devicePayload);

            	    		if(this.simulationType.equals("alarm"))
                				payload.put("n", "alarm");
                			else
                				payload.put("n", "data");
            	    		
            	        	payload.put("deviceData", deviceData);
            	        	//payload.put("t", new Timestamp(System.currentTimeMillis()));
            	        	payload.put("t",localDateFormat.format(new Date()));
            	        	payload.put("gatewayId", gateway);
            	        	payload.put("mid", 101);
            			}
            		}

            		mqttGateway.publishData(TOPIC_NAME_PREFIX + gateway, payload.toString());
            		LOGGER.info("Payload :"+ payload);
            	}
        	}
        	
        	waiter(this.frequencyValue);
    	}
    	else {
    		
    	}	 
    	
        return manualSimulationModel;
    }

	public void waiter(Long frequencyValue) throws InterruptedException {
		
		if(this.frequencyUnit.equalsIgnoreCase("sec")) {
    	  	Long timeInMilliSeconds = (long) (frequencyValue * 1000);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else if(this.frequencyUnit.equalsIgnoreCase("min")) {
    		Long timeInMilliSeconds = (long) (frequencyValue * 1000 * 60);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else if(this.frequencyUnit.equalsIgnoreCase("hrs")) {
    		Long timeInMilliSeconds = (long) (frequencyValue * 1000 * 60 * 60);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else if(this.frequencyUnit.equalsIgnoreCase("days")) {
    		Long timeInMilliSeconds = (long) (frequencyValue * 1000 * 60 * 60 * 24);
            Thread.sleep(timeInMilliSeconds);
    	}
    	else {
    		Thread.sleep(0);
    	}
    }
}