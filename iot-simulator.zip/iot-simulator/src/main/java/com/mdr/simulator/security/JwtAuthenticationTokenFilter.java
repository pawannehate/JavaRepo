package com.mdr.simulator.security;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mdr.simulator.utils.response.ErrorResponse;

public class JwtAuthenticationTokenFilter extends AbstractAuthenticationProcessingFilter{

	@Autowired
	private Environment environment;
	
	private String requestHeader;
	
	public String getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(String requestHeader) {
		this.requestHeader = requestHeader;
	}

	public JwtAuthenticationTokenFilter() {
        super("/simulate/**");
    }
	
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.requestHeader = environment.getProperty("global.jwt.header");
		String header = request.getHeader(requestHeader);

        if (header == null || !header.startsWith("Token ")) {
        	response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    		ErrorResponse errorResponse = new ErrorResponse("x0100",false, "Access denied. Token is missing.",String.valueOf(HttpServletResponse.SC_UNAUTHORIZED));
        	OutputStream out = response.getOutputStream();
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(out, errorResponse);
            out.flush();
        }

        String authenticationToken = header.substring(6);

        JwtAuthenticationToken jwtAuthenticationToken = new JwtAuthenticationToken(authenticationToken);
        return getAuthenticationManager().authenticate(jwtAuthenticationToken);
	}
	
	@Override 
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authResult) throws IOException, ServletException {
		 super.successfulAuthentication(request, response, chain, authResult);
	     	chain.doFilter(request, response);
	 }
}
