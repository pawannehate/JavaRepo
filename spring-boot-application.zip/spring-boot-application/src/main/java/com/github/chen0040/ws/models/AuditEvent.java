package com.github.chen0040.ws.models;


import lombok.Getter;
import lombok.Setter;

import java.util.Date;


/**
 * Created by xschen on 18/9/2017.
 */
@Getter
@Setter
public class AuditEvent {
   private Date time = new Date();
   private String name;
   private String description;
   private String category;
   private long tagValue;
   private String level = "info";

   public Date getTime() {
	return time;
}

public void setTime(Date time) {
	this.time = time;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}



public long getTagValue() {
	return tagValue;
}

public void setTagValue(long tagValue) {
	this.tagValue = tagValue;
}

public String getLevel() {
	return level;
}

public void setLevel(String level) {
	this.level = level;
}

public AuditEvent(){

   }

   public AuditEvent(String category, String description) {
      this.category = category;
      this.description = description;
   }
}
