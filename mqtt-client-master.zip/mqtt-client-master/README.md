# mqtt-client
A simple MQTT java client utilizing Spring Boot and the Eclipse Paho Client. Supports SSL connections and importing files to send as data to the broker. 
