package org.haughey.mqtt;

import java.io.IOException;
import java.util.UUID;

import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.stereotype.Component;
@AutoConfigureAfter
@Component
public class MqttProducer {

    @Value("${global.mqttUserName}")
    private String user;
    
    @Value("${global.mqttPassword}")
    private String password;

    @Value("${clientId:clientTest}")
    private String clientId;

    @Value("${global.mqttConnectionURL}") 
    private String host;

    @Value("${port:1883}")
    private int port;

    @Value("${waitTime:5}")
    private int waitTime;

    @Value("${qos:1}")
    private int qos;

    @Value("${topic:testTopic}")
    private String topic;

    @Value("${numMessages:100}")
    private int numMessages = 100;

  
    void messageSending(MyGateway gateway) throws IOException {
        for( int i=1; i <=3; i ++) {
            try {
                Thread.sleep(150);
                gateway.sendToMqtt("GatewayId:"+"TestGW"+i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    @Bean
    public MqttPahoClientFactory mqttClientFactory() {
        String tmpDir = System.getProperty("java.io.tmpdir");
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        java.util.Properties sslClientProps = new java.util.Properties();
        MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence(tmpDir);

        factory.setServerURIs("tcp://" + host + ":" + port);
        factory.setUserName(user);
        factory.setPassword(password);
        factory.setSslProperties(sslClientProps);
        factory.setWill(new DefaultMqttPahoClientFactory.Will(topic, "I have died...".getBytes(), qos, true ));
        factory.setPersistence(dataStore);
        factory.setKeepAliveInterval(5000);
        //factory.setPersistence(new MemoryPersistence());
        return factory;
    }
    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler mqttOutbound() {
        if (clientId.equals("clientTest")){
            clientId = UUID.randomUUID().toString();
            System.out.println(clientId);
        }
        MqttPahoMessageHandler messageHandler =
                new MqttPahoMessageHandler(clientId, mqttClientFactory());

        // The caller will not block messages waiting for a delivery confirmation when
        // a message is sent so that the message can be received. Default false
        //messageHandler.setAsync(true);
        messageHandler.setDefaultTopic(topic);
        messageHandler.setDefaultQos(qos);
        messageHandler.setCompletionTimeout(50000);
        return messageHandler;
    }

    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }

    @MessagingGateway(defaultRequestChannel = "mqttOutboundChannel") interface MyGateway {

        void sendToMqtt(String data);
    }
  

    
    
    
    
    
    
    
    
    
    
    
    
   // ++++++++++++++++++++++++++++++++++++++++++
    /**
     * The application takes in command line arguments or values provided
     * by a property file. There are set default values for the variables
     * if non are given. The program sends a message a 1000 times or the
     * given amount by the user to the topic chosen by the user to the
     * broker. Once numMessages hits its max, the application will
     * disconnect from the broker and exit.
     *
     * @param args
     *          Commandline arguments passed
     * @throws IOException
     *          Thrown if cannot read the file
     */
 /*   public static void main(String[] args) throws IOException {

        ConfigurableApplicationContext context =
                new SpringApplicationBuilder(MqttProducer.class)
                        .web(false)
                        .run(args);
        MyGateway gateway = context.getBean(MyGateway.class);

        MqttProducer producer = new MqttProducer();

        producer.messageSending(gateway);

        System.exit(0);
    }*/
    /**
     * Method readFileIn() reads the given text file into a String so that it can
     * be sent to the broker.
     *
     * @return messageData as a String
     * @throws IOException if file isn't found then IOException is thrown
     */
 /*   private String readFileIn() throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/testfilelarge.txt")));
        StringBuilder sb = new StringBuilder();
        String line = br.readLine();

        while (line != null) {
            sb.append(line);
            sb.append(System.lineSeparator());
            line = br.readLine();
        }
        String messageData = sb.toString();
        //System.out.println(messageData);

        return messageData;
    }*/
    /**
     * Method messageSending() takes the MyGateway as a parameter and then
     * reads the data from a given file to send 100 times as the default amount
     * unless the user specifies through CLA or a property file.
     *
     * @param gateway       Passes the MyGateway class instance
     * @throws IOException  If data isn't able to be read in, throws IOException
     */
   /* void messageSending(MyGateway gateway) throws IOException {

        MqttProducer messageData = new MqttProducer();

        for( int i=1; i <= numMessages; i ++) {
            // Sleep is performed in Milliseconds, 10s
            try {
                Thread.sleep(450);
                gateway.sendToMqtt(messageData.readFileIn());
                gateway.sendToMqtt("hello");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if( i % 10 == 0 ) {
                System.out.println(String.format("Sent %d numMessages.", i));
            }
        }
    }
    
    *  // TODO: Get property file to work
    /**
     * Property file that includes default values used by SpringBoot to
     * be passed if none are provided by the user through commandline.
     *
     * @return PropertySourcesPlaceholderConfigurer() new instance
     */
   /* @Bean
    public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }*/
}
