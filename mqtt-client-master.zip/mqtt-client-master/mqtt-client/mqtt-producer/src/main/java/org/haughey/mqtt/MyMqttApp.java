package org.haughey.mqtt;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.integration.annotation.IntegrationComponentScan;

@SpringBootApplication
@IntegrationComponentScan
public class MyMqttApp {

    public static void main(String[] args) throws IOException {
    	//SpringApplication.run(MyMqttApp.class, args);
    
    	//ConfigurableApplicationContext context = new SpringApplicationBuilder(MyMqttApp.class).web(false).run(args);
    ConfigurableApplicationContext context =SpringApplication.run(MyMqttApp.class, args);
    MqttProducer.MyGateway gateway = context.getBean(MqttProducer.MyGateway.class);
    // MqttProducer producer = new MqttProducer();
     // producer.messageSending(gateway);
     gateway.sendToMqtt("hello");
        //System.exit(0);
     
    }


}
